package com.example.XianweiECommerce.dto;
import lombok.Data;

@Data
public class MainCategoryDTO {
    private Long id;
    private String name;
}
